--
-- PostgreSQL database dump
--

\restrict qEblYkah6v9ZeNKMmcKBwmgnttfA2ndFvt4dXOKhQ4OWBWSf6Z6Uy8Qyd85DAQb

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: CanalNotificacion; Type: TYPE; Schema: public; Owner: paguito
--

CREATE TYPE public."CanalNotificacion" AS ENUM (
    'EMAIL',
    'WHATSAPP',
    'INTERNAL'
);


ALTER TYPE public."CanalNotificacion" OWNER TO paguito;

--
-- Name: EstadoCliente; Type: TYPE; Schema: public; Owner: paguito
--

CREATE TYPE public."EstadoCliente" AS ENUM (
    'ACTIVO',
    'BLOQUEADO'
);


ALTER TYPE public."EstadoCliente" OWNER TO paguito;

--
-- Name: EstadoNotificacion; Type: TYPE; Schema: public; Owner: paguito
--

CREATE TYPE public."EstadoNotificacion" AS ENUM (
    'PENDING',
    'SENT',
    'FAILED'
);


ALTER TYPE public."EstadoNotificacion" OWNER TO paguito;

--
-- Name: EstadoReserva; Type: TYPE; Schema: public; Owner: paguito
--

CREATE TYPE public."EstadoReserva" AS ENUM (
    'NUEVA',
    'ASIGNADA',
    'EN_VISITA',
    'PARCIAL',
    'COMPLETADA',
    'CANCELADA',
    'SIN_STOCK'
);


ALTER TYPE public."EstadoReserva" OWNER TO paguito;

--
-- Name: EstadoReservaItem; Type: TYPE; Schema: public; Owner: paguito
--

CREATE TYPE public."EstadoReservaItem" AS ENUM (
    'PENDIENTE',
    'EN_PROCESO',
    'VENDIDO',
    'NO_CONCRETADO',
    'CANCELADO',
    'SIN_STOCK'
);


ALTER TYPE public."EstadoReservaItem" OWNER TO paguito;

--
-- Name: Rol; Type: TYPE; Schema: public; Owner: paguito
--

CREATE TYPE public."Rol" AS ENUM (
    'ADMIN',
    'VENDEDOR'
);


ALTER TYPE public."Rol" OWNER TO paguito;

--
-- Name: TipoPago; Type: TYPE; Schema: public; Owner: paguito
--

CREATE TYPE public."TipoPago" AS ENUM (
    'CONTADO',
    'CREDITO'
);


ALTER TYPE public."TipoPago" OWNER TO paguito;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: paguito
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO paguito;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: paguito
--

CREATE TABLE public.customers (
    id text NOT NULL,
    "nombreCompleto" text NOT NULL,
    telefono text NOT NULL,
    curp text NOT NULL,
    email text,
    direccion text,
    estado public."EstadoCliente" DEFAULT 'ACTIVO'::public."EstadoCliente" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.customers OWNER TO paguito;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: paguito
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "reservationId" text NOT NULL,
    canal public."CanalNotificacion" NOT NULL,
    status public."EstadoNotificacion" DEFAULT 'PENDING'::public."EstadoNotificacion" NOT NULL,
    mensaje text,
    error text,
    "sentAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notifications OWNER TO paguito;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: paguito
--

CREATE TABLE public.password_reset_tokens (
    id text NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.password_reset_tokens OWNER TO paguito;

--
-- Name: products; Type: TABLE; Schema: public; Owner: paguito
--

CREATE TABLE public.products (
    id text NOT NULL,
    sku text NOT NULL,
    nombre text NOT NULL,
    marca text NOT NULL,
    descripcion text,
    precio numeric(10,2) NOT NULL,
    "precioAnterior" numeric(10,2),
    stock integer DEFAULT 0 NOT NULL,
    "stockMinimo" integer DEFAULT 5 NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    badge text,
    "disponibleCredito" boolean DEFAULT true NOT NULL,
    "pagosSemanales" text,
    especificaciones jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    imagenes text[] DEFAULT ARRAY[]::text[],
    colores text[] DEFAULT ARRAY[]::text[],
    memorias text[] DEFAULT ARRAY[]::text[],
    enganche text,
    "pagoSemanal" text
);


ALTER TABLE public.products OWNER TO paguito;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: paguito
--

CREATE TABLE public.refresh_tokens (
    id text NOT NULL,
    token text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO paguito;

--
-- Name: reservation_items; Type: TABLE; Schema: public; Owner: paguito
--

CREATE TABLE public.reservation_items (
    id text NOT NULL,
    "reservationId" text NOT NULL,
    "productId" text NOT NULL,
    color text,
    memoria text,
    "tipoPago" public."TipoPago" DEFAULT 'CONTADO'::public."TipoPago" NOT NULL,
    estado public."EstadoReservaItem" DEFAULT 'PENDIENTE'::public."EstadoReservaItem" NOT NULL,
    "precioCapturado" numeric(10,2) NOT NULL,
    notas text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.reservation_items OWNER TO paguito;

--
-- Name: reservations; Type: TABLE; Schema: public; Owner: paguito
--

CREATE TABLE public.reservations (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "vendorId" text,
    "nombreCompleto" text NOT NULL,
    telefono text NOT NULL,
    curp text NOT NULL,
    direccion text NOT NULL,
    "fechaPreferida" timestamp(3) without time zone NOT NULL,
    "horarioPreferido" text NOT NULL,
    latitude numeric(10,8),
    longitude numeric(11,8),
    estado public."EstadoReserva" DEFAULT 'NUEVA'::public."EstadoReserva" NOT NULL,
    notas text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "estadoDetalle" jsonb
);


ALTER TABLE public.reservations OWNER TO paguito;

--
-- Name: users; Type: TABLE; Schema: public; Owner: paguito
--

CREATE TABLE public.users (
    id text NOT NULL,
    nombre text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    rol public."Rol" DEFAULT 'VENDEDOR'::public."Rol" NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    zona text,
    telefono text,
    "lastAssignedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO paguito;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: paguito
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
c8d2ded5-0e3e-447b-969b-d34ab9e8fa4a	06d7bd5186f2a726a994831be43fea2b4709470771960c49d24229206825c613	2026-02-27 14:25:10.238944+00	20260227142510_init	\N	\N	2026-02-27 14:25:10.082738+00	1
64d2b71f-ba69-45ed-930f-4b19aa0ccc4b	b9fd41c458ea0ae9520c0718e3a77726c8a7384c7e99e89591f6519ace907468	2026-03-02 23:46:55.596803+00	20260302234655_add_imagenes_array	\N	\N	2026-03-02 23:46:55.564878+00	1
7f76bdaf-e771-4bda-ba13-4338a6b049a0	2fd7b5f69905a50feb63cb942a7e0487f90f194a7a1be8ccdeb1fa40ea334853	2026-03-04 07:00:38.109354+00	20260304070038_make_lat_lng_optional	\N	\N	2026-03-04 07:00:38.07187+00	1
3aa57c1e-7f37-4a13-9b65-b05c69d7cc93	bd45583dcd4ed14ce505003dbb18ce651a8543b2d034079839c2366165492cc7	2026-03-07 08:05:02.671692+00	20260307080502_add_colores_to_product	\N	\N	2026-03-07 08:05:02.649112+00	1
7edeb1d2-b47f-40fd-94ab-d6c96b946983	f4b01dda6e65a4f25c1cca61145c38a4d0f770f358f8ff24baba852a32e289b6	2026-03-07 09:07:23.072974+00	20260307090722_add_memorias_to_product	\N	\N	2026-03-07 09:07:23.055959+00	1
9f6fca0f-dcbc-4632-87d5-e3e68225756d	ccb7199f0f0d8ec2c43a33ad0b6aea5244a95655d44d284d824ea24d06b37c31	2026-03-09 06:10:01.404845+00	20260309000000_remove_round_robin_state	\N	\N	2026-03-09 06:10:01.356794+00	1
1b984740-5242-4db3-b900-5a06d281e19c	6548637b4b926edda572a891edd3e0b44ac055da89023dac053dccadd7af090e	2026-03-10 06:44:48.276598+00	20260310064448_add_refresh_tokens	\N	\N	2026-03-10 06:44:48.235284+00	1
4b96df4a-de8f-43f9-9406-97f41f491aa4	be8f754de0d94d737f5bebf3a4c47abcda5aafb22f7940e9d3fb39afa21e4bfe	2026-03-10 08:00:53.413606+00	20260310080053_add_password_reset_tokens	\N	\N	2026-03-10 08:00:53.33867+00	1
d4ae03ac-74a8-4973-98e7-7e5e932c7169	3e7c5104c692fc0081077ebfe59a38a6d0025f6c5023c4d402974cc07f974ddd	2026-03-12 06:15:03.966815+00	20260312061503_add_performance_indexes	\N	\N	2026-03-12 06:15:03.769479+00	1
04c36e98-6483-4f0a-8acc-25878b98b262	376f6fd899c2f03ac3232d0b75bb86f9e3ac97a78bd992138fea91684012f23b	2026-03-16 20:54:07.159988+00	20260316205407_change_pagos_semanales_to_string	\N	\N	2026-03-16 20:54:07.095594+00	1
0bf4be4d-2594-4a13-9b20-21547fda4b09	630a2ccab100ff2cd228b0b0eee1d50b4ac82fea32d90d71a74ae8a70249fa74	2026-03-17 14:06:13.279258+00	20260317080543_add_reservation_items_model		\N	2026-03-17 14:06:13.279258+00	0
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: paguito
--

COPY public.customers (id, "nombreCompleto", telefono, curp, email, direccion, estado, "createdAt", "updatedAt") FROM stdin;
944793cc-4cf1-48d0-9f42-dafd69296597	Liodan Sarduy Diaz	9624653406	SADL880501HNERZD01	\N	Avenida Reforma, Fracc. Valle Verde, Tapachula, Chiapas	ACTIVO	2026-03-02 23:34:38.743	2026-03-21 04:52:30.161
90c401c0-6a8f-4ef8-9d35-80ef37bf4faf	Maria Andujar	9624653406	SADL880501HNERZD02	\N	Avenida Reforma, Fracc. Valle Verde, Tapachula, Chiapas	ACTIVO	2026-03-17 06:24:51.512	2026-03-21 12:25:10.299
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: paguito
--

COPY public.notifications (id, "reservationId", canal, status, mensaje, error, "sentAt", "createdAt") FROM stdin;
f7ffbdf2-9367-493d-a221-1f2a7d560a50	4d5d8a43-4547-4149-a1d7-ff3ad1a7a2c1	INTERNAL	SENT	Nueva reserva #4D5D8A43 — Cliente: Liodan Sarduy Diaz — Producto: Samsung A07 — Maps: https://www.google.com/maps?q=14.910338149423861,-92.26316750049592	\N	2026-03-10 06:51:34.259	2026-03-10 06:51:34.263
04aa48ca-de24-4560-8d13-677a90ad10c9	9cfb5086-d723-4ac1-ac9b-592abad58ba3	INTERNAL	SENT	Nueva reserva #9CFB5086 — Cliente: Liodan Sarduy Diaz — Producto: Samsung A175F, Samsung A07 — Maps: https://www.google.com/maps?q=14.8878287,-92.2937195	\N	2026-03-21 04:52:30.318	2026-03-21 04:52:30.321
d0e50418-7865-4240-996f-ac2df5e027f6	81f18d00-18db-4a07-877d-9bb13d9f5ab1	INTERNAL	SENT	Nueva reserva #81F18D00 — Cliente: Maria Andujar — Producto: Samsung A175F — Maps: https://www.google.com/maps?q=14.8878287,-92.2937195	\N	2026-03-21 12:25:10.398	2026-03-21 12:25:10.401
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: paguito
--

COPY public.password_reset_tokens (id, token, "userId", "expiresAt", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: paguito
--

COPY public.products (id, sku, nombre, marca, descripcion, precio, "precioAnterior", stock, "stockMinimo", "isActive", badge, "disponibleCredito", "pagosSemanales", especificaciones, "createdAt", "updatedAt", imagenes, colores, memorias, enganche, "pagoSemanal") FROM stdin;
3115ceda-efb2-41d2-a4ef-7670110b8a93	APL-14PM-256	iPhone 14 Pro Max	Apple	Pantalla Super Retina XDR 6.7", chip A16 Bionic, cámara 48MP, 5G	28999.00	\N	45	5	t	Más Vendido	t	580.00	{"chip": "A16 Bionic", "camara": "48MP", "bateria": "4323 mAh", "pantalla": "6.7\\" Super Retina XDR", "conectividad": "5G"}	2026-02-27 14:25:37.29	2026-02-27 14:25:37.29	{}	{}	{}	\N	\N
48bcfb52-cce1-4c13-90e7-3676486366e4	MOT-ED40-256	Motorola Edge 40	Motorola	Pantalla pOLED 6.55" 144Hz, chip MediaTek Dimensity 8020, cámara 50MP, carga 68W	9999.00	\N	15	5	t	\N	t	200.00	{"chip": "Dimensity 8020", "camara": "50MP", "bateria": "4400 mAh", "pantalla": "6.55\\" pOLED 144Hz", "conectividad": "5G"}	2026-02-27 14:25:37.34	2026-02-27 14:25:37.34	{}	{}	{}	\N	\N
f8f9e95c-a368-4bef-8ebe-87251c7a6ad7	HON-M5L-256	Honor Magic5 Lite	Honor	Pantalla AMOLED 6.67" 120Hz, chip Snapdragon 695, cámara 64MP	6499.00	\N	20	5	t	\N	t	130.00	{"chip": "Snapdragon 695", "camara": "64MP", "bateria": "5100 mAh", "pantalla": "6.67\\" AMOLED 120Hz", "conectividad": "5G"}	2026-02-27 14:25:37.397	2026-02-27 14:25:37.397	{}	{}	{}	\N	\N
ccbc139d-3ea0-41cd-9ee0-fa57674dcfce	XIA-RN12-128	Xiaomi Redmi Note 12	Xiaomi	Pantalla AMOLED 6.67", chip Snapdragon 685, cámara 50MP	4599.00	6500.00	120	10	t	Nuevo Ingreso	t	92.00	{"chip": "Snapdragon 685", "camara": "50MP", "bateria": "5000 mAh", "pantalla": "6.67\\" AMOLED", "conectividad": "4G"}	2026-02-27 14:25:37.32	2026-03-03 06:59:03.927	{}	{}	{}	\N	\N
2f4cff95-d823-4759-a93b-5d5f1ad238b9	SAM-S23U-512	Samsung Galaxy S23 Ultra	Samsung	Pantalla Dynamic AMOLED 6.8", chip Snapdragon 8 Gen 2, cámara 200MP, S Pen incluido	26499.00	28000.00	3	5	t	Oferta	t	530.00	{"chip": "Snapdragon 8 Gen 2", "camara": "200MP", "bateria": "5000 mAh", "pantalla": "6.8\\" Dynamic AMOLED", "conectividad": "5G"}	2026-02-27 14:25:37.308	2026-03-02 23:53:28.971	{}	{}	{}	\N	\N
10120683-41b6-47a3-8ebf-80f5bb9a91d8	SAM-A54-256	Samsung Galaxy A54 5G	Samsung	Pantalla Super AMOLED 6.4", chip Exynos 1380, cámara 50MP OIS, 5G	8999.00	\N	30	5	t	\N	t	180.00	{"chip": "Exynos 1380", "camara": "50MP OIS", "bateria": "5000 mAh", "pantalla": "6.4\\" Super AMOLED", "conectividad": "5G"}	2026-02-27 14:25:37.377	2026-03-13 05:26:23.236	{}	{}	{}	\N	\N
cb9bacdd-7c86-4ba4-87c5-4ca5fd0461aa	APL-13MN-128	iPhone 13 Mini	Apple	Pantalla Super Retina XDR 5.4", chip A15 Bionic, cámara dual 12MP	14999.00	\N	4	5	t	\N	t	300.00	{"chip": "A15 Bionic", "camara": "12MP Dual", "bateria": "2438 mAh", "pantalla": "5.4\\" Super Retina XDR", "conectividad": "5G"}	2026-02-27 14:25:37.365	2026-03-13 05:26:25.283	{}	{}	{}	\N	\N
dc929369-e4b1-4de2-890e-8971ce1e7717	SAM-A07-64	Samsung A07	Samsung	descripcion de ejemplo	2000.00	\N	10	3	t	\N	t	100.00	{"Red": "5G", "Cámara": "Frontal: 15 MP\\nTrasera: 50 MP", "Memoria": "128 GB", "Batería": "5000 mah", "Pantalla": "6.8\\"", "Procesador": "Snapdragon 8 core 2.2", "Conexiones Inalámbricas": "Wifi\\nUSB"}	2026-03-06 06:54:30.825	2026-03-16 20:29:08.752	{}	{Negro,Azul,"Azul claro"}	{"64 GB","128 GB"}	\N	\N
6788fb1d-0625-4d32-af48-d90b4cd5cc92	OPP-RN10-256	OPPO Reno 10 5G	OPPO	Pantalla AMOLED 6.7" 120Hz, chip Snapdragon 778G, cámara telefoto 32MP	9999.00	\N	12	5	t	\N	t	200.00	{"chip": "Snapdragon 778G", "camara": "64MP + 32MP Telefoto", "bateria": "5000 mAh", "pantalla": "6.7\\" AMOLED 120Hz", "conectividad": "5G"}	2026-02-27 14:25:37.413	2026-03-13 05:26:19.109	{}	{}	{}	\N	\N
f9c4675b-be36-4b56-bca3-712fc5b8418f	SAM-A175F-128	Samsung A175F	Samsung	Con una experiencia fluida gracias a su pantalla AMOLED de 90Hz, y bateria de larga duración de 5, 000 mAh, disfruta de tu contenido favorito. \r\n\r\nUn equipo hecho para durar, con mayor nitidez y estabilidad para desafiar la forma en la que capturas tus mejores momentos.	2999.00	\N	5	2	t		t	Enganche: $350 a $1050\r\nPagos semanales: $100 a $140 (39 semanas)	{"Red": "4G", "Cámara": "Frontal: 13\\nTrasera: 50 + 5 + 2", "Batería": "5000 mAh", "Pantalla": "6.8\\"", "Procesador": "MEDIATEK Helio G99 Octa-core (2x 2.2GHz + 6x 2.0GHz)", "Sistema Operativo": "Android 15"}	2026-03-16 19:56:40.911	2026-03-18 04:41:56.348	{/uploads/productos/1773705375148-348749637.png,/uploads/productos/1773705508937-306630154.png}	{Negro,Azul,Gris}	{"128 GB"}	\N	\N
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: paguito
--

COPY public.refresh_tokens (id, token, "userId", "expiresAt", "revokedAt", "createdAt") FROM stdin;
37ca9c5c-054c-453c-a233-2474306f42bf	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzMDUxMDIsImV4cCI6MTc3MzkwOTkwMn0.D35X3Ol5tpSJGYGRFQQ2_UGieU9ux_mFKcc7cvqnbxo	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-19 08:45:02.645	\N	2026-03-12 08:45:02.646
f5a8a3ad-e52e-460e-8d39-e72e5e949982	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzMDY0MzYsImV4cCI6MTc3MzkxMTIzNn0.MM7vaYIgpPQqdCsN5pu3bhZL9DXRWwX0JD0c0x7qsVc	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-19 09:07:16.329	\N	2026-03-12 09:07:16.33
b219b429-d725-48ad-8957-78c49587ebea	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzNzY1NDIsImV4cCI6MTc3Mzk4MTM0Mn0.dlSXF8-1XczU3C94efhOuU7f9LfPlTBaYSapeK8Xn1I	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-20 04:35:42.477	\N	2026-03-13 04:35:42.485
ecf91349-eede-4482-ac98-2eb8a63ba7ba	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzNzk1MjEsImV4cCI6MTc3Mzk4NDMyMX0.CXnk4AQFTtT8m28l0nf8Sj12g0Ar_WPBYYcoKhqhrw4	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-20 05:25:21.89	\N	2026-03-13 05:25:21.897
b653d438-2fb6-4b83-9ba6-b7922c4766e4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzODE0MDgsImV4cCI6MTc3Mzk4NjIwOH0.ExfSEv7d41ArCsmV7MWVU0YddF4HG3eSv2KL7y1_LW0	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-20 05:56:48.749	\N	2026-03-13 05:56:48.749
e41cfde1-6a78-4cb5-a70f-98262ac28a33	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzODIzNDcsImV4cCI6MTc3Mzk4NzE0N30.NGDsEe4MzGW26koMmgCBVqgUeSXfVAPc2VGtib0MWoU	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-20 06:12:27.445	\N	2026-03-13 06:12:27.458
9b02993c-5e74-4679-a555-5afe1669cd85	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzODM1NzEsImV4cCI6MTc3Mzk4ODM3MX0.rM_dgUA2Dk9j2_t4G_o3ZSt5Sd-jLNIad71Z0vEOBbo	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-20 06:32:51.539	\N	2026-03-13 06:32:51.539
0e62cdaf-54ff-4d86-927d-213f6a7b1a79	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzODU4OTgsImV4cCI6MTc3Mzk5MDY5OH0.S0Al-UychVgXYHaRRNRDRNuQVcOyKQ1yzKJoY4lQWkM	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-20 07:11:38.642	\N	2026-03-13 07:11:38.658
f2e4a412-f522-441e-a90f-a2e163b88835	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzODcyNzUsImV4cCI6MTc3Mzk5MjA3NX0.kkjlAJJ92-DLvFASd7Kc0d2EYHiXKpnTQctXQiiZuSg	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-20 07:34:35.969	\N	2026-03-13 07:34:35.969
1de9c0ea-b84d-420e-926f-4568d795bc5a	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzODgyMTYsImV4cCI6MTc3Mzk5MzAxNn0.uFPSPBipBFCx3ukJFDd-LFY5_0kwgr2X_I2FmP4XXpc	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-20 07:50:16.922	\N	2026-03-13 07:50:16.922
24423dcc-95c8-4d4b-ba05-a140bc8f7c4a	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzMzOTAxMTMsImV4cCI6MTc3Mzk5NDkxM30.KJPDi-ZFfwTYBidIdbTb4QfN6x47ddHWkzMM9uzi-3Y	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-20 08:21:53.968	\N	2026-03-13 08:21:53.968
d4f1a88c-42ff-4743-979a-eeb9903cf8e3	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM1NTEzNDIsImV4cCI6MTc3NDE1NjE0Mn0.QiAUU8rvnu4_jr5VRBnD6SGpLa4wli0q71DkDmk5Hfw	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-22 05:09:02.525	\N	2026-03-15 05:09:02.536
fadaa620-41ce-46fe-9003-e16c2307f435	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2MjAzNzMsImV4cCI6MTc3NDIyNTE3M30.xiPzDZ9cebUjbn5iRBqMPVuVV3wsW917oukPF5UiUmw	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 00:19:33.368	\N	2026-03-16 00:19:33.369
df31ce22-b06d-4a5f-a24c-565e213d3603	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2ODQ2NTIsImV4cCI6MTc3NDI4OTQ1Mn0.SOkttyUR1JWbSXEHm_O7nz823S03b-vn8p04cNhmeNE	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 18:10:52.004	\N	2026-03-16 18:10:52.004
a9e5579a-a006-485f-878d-4c7fda2e71f7	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2ODU4MDQsImV4cCI6MTc3NDI5MDYwNH0.bx-nH2DNPrSC74oBHhXxjsVSB7IzzWEB5OGBdrQCIgM	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 18:30:04.679	\N	2026-03-16 18:30:04.679
a530fc28-3cd7-47ab-88b7-6e3f67c972ce	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2ODk5MzIsImV4cCI6MTc3NDI5NDczMn0.6eVRBYyk5lK3EHacm4DJW9q-kwAPe9X100YvHAmyg00	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 19:38:52.695	\N	2026-03-16 19:38:52.695
17521c6b-683c-447c-894a-b1bdf6983910	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2OTA5NTAsImV4cCI6MTc3NDI5NTc1MH0.815JGM4nsfepblsur7s0vlP_Tfk_spXPifsEQSqh4xI	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 19:55:50.987	\N	2026-03-16 19:55:50.987
2120df60-b62a-4f82-be36-1ed9c8c89c49	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2OTIxMzIsImV4cCI6MTc3NDI5NjkzMn0.Gp6PE0qRIqwDh1VUfSVLR-7nXcWqW1mFpLy-vYPRKNo	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 20:15:32.911	\N	2026-03-16 20:15:32.912
405c57e3-a20f-43d3-bcbe-524e16c7be7d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2OTMwNjgsImV4cCI6MTc3NDI5Nzg2OH0.dNHGclNfrYABGjLNa8vCzZ96-TxS7AB_8wpF4bAaiYU	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 20:31:08.597	\N	2026-03-16 20:31:08.597
057d98f5-09a9-4011-857f-6f30558b9e8a	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2OTM1NTEsImV4cCI6MTc3NDI5ODM1MX0.FevNkqm7CrWW1H7xvoZup8KbqDHdCjnTCH4xZsU1V4w	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 20:39:11.534	\N	2026-03-16 20:39:11.534
b11202ae-fdee-43f7-92a5-2a523c26e63b	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2OTQ2MjgsImV4cCI6MTc3NDI5OTQyOH0.UY5FGrUBi1nTa-iChlqK5HPHOg5qNhGCdeEVNeVhWew	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 20:57:08.491	\N	2026-03-16 20:57:08.499
0e053223-3075-4883-93a7-9c923e14b045	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM2OTk0MTgsImV4cCI6MTc3NDMwNDIxOH0.GukyHIDiwdqzTIdWnjmEm3mypfe1lMCHhQcFuJUyydI	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 22:16:58.211	\N	2026-03-16 22:16:58.214
04efef01-328f-47c8-9f90-71e5e99276da	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM3MDAyODUsImV4cCI6MTc3NDMwNTA4NX0.KULWBOQ30C3DMlENvS5Odt76JP3eFARMH4F_IrYs0_4	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 22:31:25.875	\N	2026-03-16 22:31:25.875
5e91f0d2-b7c7-4e1c-8da7-2cd4c9bb8867	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM3MDA3NzcsImV4cCI6MTc3NDMwNTU3N30.p7VHbgdrZq_QJF_f7nad0s1KCTh76LpR2XmcsPna3sU	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 22:39:37.343	\N	2026-03-16 22:39:37.353
c4289c99-d12c-4dda-accf-41c0f8bdc190	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM3MDA5ODgsImV4cCI6MTc3NDMwNTc4OH0.YhiqX0g-HsHaxSLNFQWB99Mh84-HFWWlGOIxt5Ocemw	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 22:43:08.437	\N	2026-03-16 22:43:08.438
d8c133ed-97b1-4577-89db-5c2f2b7d2553	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM3MDIwOTEsImV4cCI6MTc3NDMwNjg5MX0.9usZojrqWxUZzte4Cy-8r6acjaUq2vz8CyXV92vMIzw	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 23:01:31.533	\N	2026-03-16 23:01:31.533
fe66c1d8-299b-4a19-9b74-7fb711b02367	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM3MDM3MzcsImV4cCI6MTc3NDMwODUzN30.5Lma8-L9BXoGqDzvPt1-2FKaOLfJ5R2c1xgO1gFE3gI	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 23:28:57.41	\N	2026-03-16 23:28:57.411
53490a4a-7377-4475-baed-ce7e8325ff51	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM3MDUzMzUsImV4cCI6MTc3NDMxMDEzNX0.dEKv4n6ubcpdVU2iBXpoB65dp4un5IM9-tzUrG5BD2g	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-23 23:55:35.209	\N	2026-03-16 23:55:35.22
47d937ce-5394-4e62-a87a-a4c3878f5865	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM3Mjk1MTMsImV4cCI6MTc3NDMzNDMxM30.-vnK8McxGmZDKpIqdU32cgqZG7261sd2_sZpQs413Ig	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-24 06:38:33.241	\N	2026-03-17 06:38:33.249
fcd08715-24b2-4f1c-9fb3-858e96510628	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM4MDg0NzYsImV4cCI6MTc3NDQxMzI3Nn0.Nkd_Q9X1Ux-BzM7Jkc9Bb8qQDUzcBOqTbQ7rH6Z4ycg	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-25 04:34:36.363	\N	2026-03-18 04:34:36.442
47aff59c-d775-4aff-becd-494658fd78ce	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM4MDg0OTMsImV4cCI6MTc3NDQxMzI5M30.I1_GZe-AtFgu2mV-n5z1G-BKvma0FvfeiScw9aX8q4g	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-25 04:34:53.435	\N	2026-03-18 04:34:53.435
71fd201e-4c3c-4276-a68c-4f6a28fde75b	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM4MTAyMTYsImV4cCI6MTc3NDQxNTAxNn0.1fve2ZqEYyKzzltDy5cbF2ozPQfPYQqwh7SnSZJxS_k	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-25 05:03:36.347	\N	2026-03-18 05:03:36.348
1069b6ca-1d73-4953-ba1d-c948b01baea8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM4Mzc5NjIsImV4cCI6MTc3NDQ0Mjc2Mn0.h0V_y8hghTblxzWaEnECMdhNh9Gv7ooY4X84-YILQhw	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-25 12:46:02.546	\N	2026-03-18 12:46:02.558
0a42d105-b52b-4a41-bbba-c61cbdb02bc2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM5MDAzNzcsImV4cCI6MTc3NDUwNTE3N30.uKLIBknX7HoDmFfaISxwvXMXLEz4hR6cxJ4UW0NdqBs	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-26 06:06:17.393	\N	2026-03-19 06:06:17.412
6556cb18-a4b2-4b29-8dbf-194dc2ce8f22	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM5MDA1NjQsImV4cCI6MTc3NDUwNTM2NH0.yb0GwIFPov8jxO9Fmw73xw1QisPXswUyFNr1iFMWRD4	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-26 06:09:24.263	\N	2026-03-19 06:09:24.263
30972b4a-ae76-4f51-8341-c6c72576b462	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM5MDE5OTAsImV4cCI6MTc3NDUwNjc5MH0.GofmH0cZ-PJVbd3_dVrQSd0vrxIo3RIhKrebFhVdtc0	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-26 06:33:10.846	\N	2026-03-19 06:33:10.846
28eac0ff-84ab-42de-8c71-62f8cce4dda7	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiIwMDVhNDQzMy0xNmQwLTRmMDgtOWY1NC1iNmVlNDgyNzJkZGYiLCJlbWFpbCI6ImFkbWluQHBhZ3VpdG8uY29tIiwicm9sIjoiQURNSU4iLCJpYXQiOjE3NzM5MDIwNzgsImV4cCI6MTc3NDUwNjg3OH0.4u3Me7PnFhkx5EF-FK3Hwi5np1_xNQYsQzNdi8To6MM	005a4433-16d0-4f08-9f54-b6ee48272ddf	2026-03-26 06:34:38.524	\N	2026-03-19 06:34:38.524
846633ac-62cb-4be7-bb23-1adbc0573901	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzczOTAyNzA3LCJleHAiOjE3NzQ1MDc1MDd9.3VxNCee6OVTw5anJxo3kmC1kqXEQ7xPghtKOXqNLCYE	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-26 06:45:07.951	\N	2026-03-19 06:45:07.951
740e08f6-1c04-4e76-8d4b-d9e895e8a67c	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzczOTAzMDcwLCJleHAiOjE3NzQ1MDc4NzB9.VXFgEaC1CB0Zqu_iJn-arO1Ky_hF5moCuPG5l93HOJg	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-26 06:51:10.852	\N	2026-03-19 06:51:10.853
d31819cd-c122-418f-89fc-7ce972b3b3c3	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzczOTA0NTMyLCJleHAiOjE3NzQ1MDkzMzJ9.savtg1fYBNPlMsB9TAWtoWtmEsAI_mVr-Vr4tBOUz_U	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-26 07:15:32.391	\N	2026-03-19 07:15:32.391
af989f58-001e-4935-bf05-13ceaa6a7fed	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDUzNTkzLCJleHAiOjE3NzQ2NTgzOTN9.YANGAfx_M-FlesPMdtToH0EpUPsPQcgIxW7R8BemR7w	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 00:39:53.841	\N	2026-03-21 00:39:53.85
211eb5cb-e2c5-46a2-b63c-70212a130899	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU1NDQxLCJleHAiOjE3NzQ2NjAyNDF9.uvdxYfkqtJ_BB8rjwVylx7n_HURRhTn0cQ6RrBU2Bqg	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 01:10:41.967	\N	2026-03-21 01:10:41.979
2b4e909d-8fcb-4fc9-93b4-b892e561b5ee	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU2MDE2LCJleHAiOjE3NzQ2NjA4MTZ9.RL9AiDBLSViEMXtMxbbv_g0yZQPdmuyEoEI7psYqxNM	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 01:20:16.687	\N	2026-03-21 01:20:16.694
c3f89d06-53de-4910-8cc0-19d11f4d64d8	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU2MzI3LCJleHAiOjE3NzQ2NjExMjd9.-wTIgZU3nOrVJZHMMJORkIJSDN2AycUHLJVecc-pdAs	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 01:25:27.404	\N	2026-03-21 01:25:27.405
45ce9cd2-4fda-47ca-8667-f34c01ea2d60	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU2Njc4LCJleHAiOjE3NzQ2NjE0Nzh9.TjCdDyFGUWAecOk36vz5vxu-Wiob4Pzx2lQbU3Qjxm4	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 01:31:18.266	\N	2026-03-21 01:31:18.267
a2e7ac3d-d30d-42a7-92a1-0dfd82c4adc4	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU2NjkwLCJleHAiOjE3NzQ2NjE0OTB9.L4YdZnMKVioyX9KEoa4g39C62WSoR4KxbtWsi_Rw2lw	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 01:31:30.426	\N	2026-03-21 01:31:30.426
08551edb-161a-4b8b-a930-8e8f2cae36c0	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU3MTI1LCJleHAiOjE3NzQ2NjE5MjV9.0PgN7p49DF8mZDFwbVQxX21credIKu8jySyOd3Gct84	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 01:38:45.854	\N	2026-03-21 01:38:45.854
b1d8069e-1269-4822-afcf-68682ffd4c9e	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU3MTM3LCJleHAiOjE3NzQ2NjE5Mzd9.G7v6NClCliES7gZABMMJmvduYvrf70YdT0oNkKJnbbc	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 01:38:57.765	\N	2026-03-21 01:38:57.766
740ca06d-2805-42c8-93e8-76faa60a4f06	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU3Mzc2LCJleHAiOjE3NzQ2NjIxNzZ9._NYneD6ZHowcr4jjggv-W76xPGjTnZv8cgiSbEECSpw	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 01:42:56.97	\N	2026-03-21 01:42:56.97
808e32a5-a56a-48c6-b158-99265472c1b2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU4NDUyLCJleHAiOjE3NzQ2NjMyNTJ9.hhzvNLMhvFLu2vqeQR8_hjn1wB1j-1TJfDju2-mE6jw	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 02:00:52.797	\N	2026-03-21 02:00:52.797
2954ea11-c405-453d-9145-db1c80695e90	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU4NjU5LCJleHAiOjE3NzQ2NjM0NTl9.TK2culpoXgeEuBrElM0ecQlGKcdXuFVt5A48xoBXEQk	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 02:04:19.014	\N	2026-03-21 02:04:19.014
f8a97948-6f70-4bbf-89ff-353337b701ce	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDU5NjMwLCJleHAiOjE3NzQ2NjQ0MzB9.6JbEM8aVNVtxQcJ0JaHw4VBL33E9wYeyJmTsd54Kevg	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 02:20:30.911	\N	2026-03-21 02:20:30.911
6d867f93-fad0-4e02-85d0-7e22757d06ed	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDY4Nzk2LCJleHAiOjE3NzQ2NzM1OTZ9.SxwX-BJNZqqNnoQxe2mL4ro17ekZ-_PzODkhyzc8UCI	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 04:53:16.875	\N	2026-03-21 04:53:16.876
0a2ef40a-5000-4eb9-b3dd-9aaf335141ee	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDk1NzEzLCJleHAiOjE3NzQ3MDA1MTN9.PXetaEbIuNs7BCFTPfK2TeBbefsk8ADHUloIxvDLHrY	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 12:21:53.742	\N	2026-03-21 12:21:53.753
c9095816-ab29-4cc3-b47d-bf5517fe7481	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDk3MzIzLCJleHAiOjE3NzQ3MDIxMjN9.9Kxz3zjEQyc5_woTy0UAkQIaALG9h9Rkn8wIJaa7CDM	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 12:48:43.803	\N	2026-03-21 12:48:43.803
40aae282-676f-4262-86f1-4f8946e0ea10	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MDk3OTkwLCJleHAiOjE3NzQ3MDI3OTB9.pt8APs65tNILZ95NmDTRdrx8WkqmFjpZJL1KtEEbDTs	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-28 12:59:50.181	\N	2026-03-21 12:59:50.182
413e02b7-bc1a-4ef6-9a26-e06ea88b1c6b	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MjE1NTA2LCJleHAiOjE3NzQ4MjAzMDZ9.xt1_VaEzsUdrstv8aR14MjX4nRpUN1dYYOHBoPwd1ug	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-29 21:38:26.284	\N	2026-03-22 21:38:26.294
2d1131d5-49d1-4315-be00-fca5a01dd7a5	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MjE2NzI3LCJleHAiOjE3NzQ4MjE1Mjd9.6ZdR38rX1ZsTgj-oU3cDsrAdepjzHYd80QoJG1yZU_o	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-29 21:58:47.951	\N	2026-03-22 21:58:47.951
cf8990ca-0291-4966-a96f-8a0a1897e175	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MjE3ODkzLCJleHAiOjE3NzQ4MjI2OTN9.MJssuhy37_N2Tcdj4IHwhmLszViYuK5cUF1FcdumTnc	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-29 22:18:13.216	\N	2026-03-22 22:18:13.216
a41c1aae-508c-4e5b-a12b-15d1beba4501	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiJkNjE0ZDBiZi1lNzZiLTQ1YTgtYTk2Mi1iNTZiZGE2ZTk0ZGEiLCJlbWFpbCI6InJvYmVydG9AcGFndWl0by5jb20iLCJyb2wiOiJWRU5ERURPUiIsImlhdCI6MTc3NDIyMjg5MCwiZXhwIjoxNzc0ODI3NjkwfQ.o_wKg4pyJv0VRGMqMMvvGEVJ0TLFQLEnMnm4SrZf-yM	d614d0bf-e76b-45a8-a962-b56bda6e94da	2026-03-29 23:41:30.503	\N	2026-03-22 23:41:30.503
43525d5e-319e-425b-9f5f-4e8f809c986d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MjIyOTExLCJleHAiOjE3NzQ4Mjc3MTF9.7hW3xGY65rRzCsYjWfLs5p8naLFyh6025P9aBgrgbaQ	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-29 23:41:51.062	\N	2026-03-22 23:41:51.062
d68167d4-baee-416f-b80c-8d3d82aa17ec	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MjI0NTUwLCJleHAiOjE3NzQ4MjkzNTB9.OpNoXOxIYwpw3t7fxPZlnHZehGE2QXPnNQCt0umBgBw	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-30 00:09:10.189	\N	2026-03-23 00:09:10.19
d6b840f9-1d3e-47ca-a0ad-670a3ff9376d	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MjI1NDczLCJleHAiOjE3NzQ4MzAyNzN9.PkVcYXpOH44cRrACYo18JW9UzEvUNCz-o1ZGblOd7IU	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-30 00:24:33.103	\N	2026-03-23 00:24:33.103
4b0cc981-f10c-43cf-9a68-28a220219e0c	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MjMyMTY5LCJleHAiOjE3NzQ4MzY5Njl9.NRxwfo8Sfi88o5_2idtzse2Tly_cyrkHrk_v_fgQ8CY	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-30 02:16:09.526	\N	2026-03-23 02:16:09.535
75ccc1fb-78b1-4208-a255-468dd133b90f	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MjQ2MTkwLCJleHAiOjE3NzQ4NTA5OTB9.nUt9fueOkzGxO5_CLEdxpyyUz9MLTQV-ohu2Fx0t92o	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-30 06:09:50.305	\N	2026-03-23 06:09:50.305
568b854d-ccea-4ad4-96dd-1353e27e69d2	eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiI4NzY4MDdkZS1jYzU1LTRjMzYtYTgzZi00ZWVjYjg4Nzc2NDkiLCJlbWFpbCI6Imxpb2RhbnNkaWF6QGdtYWlsLmNvbSIsInJvbCI6IkFETUlOIiwiaWF0IjoxNzc0MjQ3Mzg5LCJleHAiOjE3NzQ4NTIxODl9._wL2WfZPa-OIjZAPsJyullWOQ2UJM5SNc_3H3x6sRfU	876807de-cc55-4c36-a83f-4eecb8877649	2026-03-30 06:29:49.426	\N	2026-03-23 06:29:49.426
\.


--
-- Data for Name: reservation_items; Type: TABLE DATA; Schema: public; Owner: paguito
--

COPY public.reservation_items (id, "reservationId", "productId", color, memoria, "tipoPago", estado, "precioCapturado", notas, "createdAt", "updatedAt") FROM stdin;
1773756324461-ajmd7z35v	4d5d8a43-4547-4149-a1d7-ff3ad1a7a2c1	dc929369-e4b1-4de2-890e-8971ce1e7717	\N	\N	CREDITO	CANCELADO	2000.00	\N	2026-03-17 14:05:24.465	2026-03-17 14:05:24.465
0362f5e1-13ce-4a6b-bedb-8aac22489912	9cfb5086-d723-4ac1-ac9b-592abad58ba3	f9c4675b-be36-4b56-bca3-712fc5b8418f	\N	\N	CREDITO	PENDIENTE	2999.00	\N	2026-03-21 04:52:30.248	2026-03-21 04:52:30.248
6c64680b-2e33-4068-a810-31b5ef2badbe	9cfb5086-d723-4ac1-ac9b-592abad58ba3	dc929369-e4b1-4de2-890e-8971ce1e7717	Negro	64 GB	CONTADO	PENDIENTE	2000.00	\N	2026-03-21 04:52:30.248	2026-03-21 04:52:30.248
e7193b8d-8bb7-4ade-8f75-adc24a7cdec2	81f18d00-18db-4a07-877d-9bb13d9f5ab1	f9c4675b-be36-4b56-bca3-712fc5b8418f	Gris	128 GB	CREDITO	CANCELADO	2999.00	Cancelado por el cliente desde la web.	2026-03-21 12:25:10.346	2026-03-22 21:40:22.198
\.


--
-- Data for Name: reservations; Type: TABLE DATA; Schema: public; Owner: paguito
--

COPY public.reservations (id, "customerId", "vendorId", "nombreCompleto", telefono, curp, direccion, "fechaPreferida", "horarioPreferido", latitude, longitude, estado, notas, "createdAt", "updatedAt", "estadoDetalle") FROM stdin;
9cfb5086-d723-4ac1-ac9b-592abad58ba3	944793cc-4cf1-48d0-9f42-dafd69296597	9ecf0fb5-efc7-40ed-ad88-a03cadee1557	Liodan Sarduy Diaz	9624653406	SADL880501HNERZD01	Avenida Reforma, Fracc. Valle Verde, Tapachula, Chiapas	2026-03-24 00:00:00	10:00	14.88782870	-92.29371950	ASIGNADA	\N	2026-03-21 04:52:30.248	2026-03-21 04:52:30.293	{"total": 2, "sinStock": 0, "vendidos": 0, "enProceso": 0, "cancelados": 0, "pendientes": 2, "noConcretados": 0}
81f18d00-18db-4a07-877d-9bb13d9f5ab1	90c401c0-6a8f-4ef8-9d35-80ef37bf4faf	d614d0bf-e76b-45a8-a962-b56bda6e94da	Maria Andujar	9624653406	SADL880501HNERZD02	Avenida Reforma, Fracc. Valle Verde, Tapachula, Chiapas	2026-03-24 00:00:00	12:00	14.88782870	-92.29371950	EN_VISITA		2026-03-21 12:25:10.346	2026-03-22 23:50:26.655	{"total": 1, "sinStock": 0, "vendidos": 0, "enProceso": 0, "cancelados": 1, "pendientes": 0, "noConcretados": 0}
4d5d8a43-4547-4149-a1d7-ff3ad1a7a2c1	944793cc-4cf1-48d0-9f42-dafd69296597	d614d0bf-e76b-45a8-a962-b56bda6e94da	Liodan Sarduy Diaz	9624653406	SADL880501HNERZD01	ANTORCHA NUMERO 13	2026-03-12 06:00:00	15:54	14.91033815	-92.26316750	ASIGNADA	Cancelada por el cliente desde la web.	2026-03-10 06:51:34.235	2026-03-22 23:50:38.633	{"total": 1, "vendidos": 0, "cancelados": 1, "pendientes": 0, "noConcretados": 0}
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: paguito
--

COPY public.users (id, nombre, email, password, rol, "isActive", zona, telefono, "lastAssignedAt", "createdAt", "updatedAt") FROM stdin;
005a4433-16d0-4f08-9f54-b6ee48272ddf	Admin Paguito	admin@paguito.com	$2b$12$0aoFdsCIp0FaUJEWOZJ2J.qWQiUS/4YhmgcigCJUbDb1LT258LmPq	ADMIN	t	\N	\N	\N	2026-02-27 14:25:36.848	2026-02-27 14:25:36.848
4a440de7-69f0-49e3-be57-fb22060dd5a3	Ana López	ana@paguito.com	$2b$12$Np3AeKSVZawy0NWvKdzoYu734fJlBQkQ9F0HQK9IDtm783NF5lsF6	VENDEDOR	t	Santa Fe	5544567890	2026-03-17 00:08:30.938	2026-02-27 14:25:37.265	2026-03-17 00:08:30.939
876807de-cc55-4c36-a83f-4eecb8877649	Liodan Sarduy Diaz	liodansdiaz@gmail.com	$2b$12$spHjFwMjuE1EKygsTZfWyOvbHJIddFIPlE3rshBM6qeAH35ghmTlC	ADMIN	t	\N	9624653406	\N	2026-03-19 06:44:59.301	2026-03-19 06:44:59.301
9ecf0fb5-efc7-40ed-ad88-a03cadee1557	Carlos Ruiz	carlos@paguito.com	$2b$12$Np3AeKSVZawy0NWvKdzoYu734fJlBQkQ9F0HQK9IDtm783NF5lsF6	VENDEDOR	t	Del Valle	5555678901	2026-03-21 04:52:30.184	2026-02-27 14:25:37.277	2026-03-21 04:52:30.186
d614d0bf-e76b-45a8-a962-b56bda6e94da	Roberto Gómez	roberto@paguito.com	$2b$12$vH5Z8lWSMFDCePro6anXOuHEaXVbmFkXF.TO9Sxgu2L7fIduVqmqS	VENDEDOR	t	Tapachula	5511234567	2026-03-21 12:25:10.314	2026-02-27 14:25:37.229	2026-03-22 22:19:49.413
06d525f6-111a-41c6-a7d8-cb4ea9f8533f	María Fernández	maria@paguito.com	$2b$12$h8GmHTR5unpT7oBmr6X1Hulga.2xxcBT3CBONPvrl9YGrlriyvfkO	VENDEDOR	t	Tapachula	5522345678	2026-03-17 06:24:51.551	2026-03-04 14:53:26.622	2026-03-22 22:20:00.354
049d6822-d6d7-4f10-9668-311066f53526	Luis Martínez	luis@paguito.com	$2b$12$Np3AeKSVZawy0NWvKdzoYu734fJlBQkQ9F0HQK9IDtm783NF5lsF6	VENDEDOR	t	Tapachula	5533456789	2026-03-16 20:34:00.799	2026-02-27 14:25:37.256	2026-03-22 22:20:10.713
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: reservation_items reservation_items_pkey; Type: CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.reservation_items
    ADD CONSTRAINT reservation_items_pkey PRIMARY KEY (id);


--
-- Name: reservations reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT reservations_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: customers_curp_key; Type: INDEX; Schema: public; Owner: paguito
--

CREATE UNIQUE INDEX customers_curp_key ON public.customers USING btree (curp);


--
-- Name: customers_estado_createdAt_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "customers_estado_createdAt_idx" ON public.customers USING btree (estado, "createdAt");


--
-- Name: notifications_reservationId_status_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "notifications_reservationId_status_idx" ON public.notifications USING btree ("reservationId", status);


--
-- Name: password_reset_tokens_token_key; Type: INDEX; Schema: public; Owner: paguito
--

CREATE UNIQUE INDEX password_reset_tokens_token_key ON public.password_reset_tokens USING btree (token);


--
-- Name: password_reset_tokens_userId_expiresAt_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "password_reset_tokens_userId_expiresAt_idx" ON public.password_reset_tokens USING btree ("userId", "expiresAt");


--
-- Name: products_isActive_createdAt_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "products_isActive_createdAt_idx" ON public.products USING btree ("isActive", "createdAt");


--
-- Name: products_isActive_marca_createdAt_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "products_isActive_marca_createdAt_idx" ON public.products USING btree ("isActive", marca, "createdAt");


--
-- Name: products_sku_key; Type: INDEX; Schema: public; Owner: paguito
--

CREATE UNIQUE INDEX products_sku_key ON public.products USING btree (sku);


--
-- Name: refresh_tokens_token_key; Type: INDEX; Schema: public; Owner: paguito
--

CREATE UNIQUE INDEX refresh_tokens_token_key ON public.refresh_tokens USING btree (token);


--
-- Name: refresh_tokens_userId_expiresAt_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "refresh_tokens_userId_expiresAt_idx" ON public.refresh_tokens USING btree ("userId", "expiresAt");


--
-- Name: refresh_tokens_userId_revokedAt_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "refresh_tokens_userId_revokedAt_idx" ON public.refresh_tokens USING btree ("userId", "revokedAt");


--
-- Name: reservation_items_productId_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "reservation_items_productId_idx" ON public.reservation_items USING btree ("productId");


--
-- Name: reservation_items_reservationId_estado_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "reservation_items_reservationId_estado_idx" ON public.reservation_items USING btree ("reservationId", estado);


--
-- Name: reservation_items_reservationId_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "reservation_items_reservationId_idx" ON public.reservation_items USING btree ("reservationId");


--
-- Name: reservation_items_tipoPago_estado_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "reservation_items_tipoPago_estado_idx" ON public.reservation_items USING btree ("tipoPago", estado);


--
-- Name: reservations_curp_estado_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX reservations_curp_estado_idx ON public.reservations USING btree (curp, estado);


--
-- Name: reservations_estado_createdAt_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "reservations_estado_createdAt_idx" ON public.reservations USING btree (estado, "createdAt");


--
-- Name: reservations_vendorId_estado_createdAt_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "reservations_vendorId_estado_createdAt_idx" ON public.reservations USING btree ("vendorId", estado, "createdAt");


--
-- Name: reservations_vendorId_fechaPreferida_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "reservations_vendorId_fechaPreferida_idx" ON public.reservations USING btree ("vendorId", "fechaPreferida");


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: paguito
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: users_isActive_rol_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "users_isActive_rol_idx" ON public.users USING btree ("isActive", rol);


--
-- Name: users_isActive_rol_lastAssignedAt_createdAt_idx; Type: INDEX; Schema: public; Owner: paguito
--

CREATE INDEX "users_isActive_rol_lastAssignedAt_createdAt_idx" ON public.users USING btree ("isActive", rol, "lastAssignedAt", "createdAt");


--
-- Name: notifications notifications_reservationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_reservationId_fkey" FOREIGN KEY ("reservationId") REFERENCES public.reservations(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: password_reset_tokens password_reset_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT "password_reset_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reservation_items reservation_items_productId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.reservation_items
    ADD CONSTRAINT "reservation_items_productId_fkey" FOREIGN KEY ("productId") REFERENCES public.products(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reservation_items reservation_items_reservationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.reservation_items
    ADD CONSTRAINT "reservation_items_reservationId_fkey" FOREIGN KEY ("reservationId") REFERENCES public.reservations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reservations reservations_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT "reservations_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: reservations reservations_vendorId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: paguito
--

ALTER TABLE ONLY public.reservations
    ADD CONSTRAINT "reservations_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict qEblYkah6v9ZeNKMmcKBwmgnttfA2ndFvt4dXOKhQ4OWBWSf6Z6Uy8Qyd85DAQb

